import os
import numpy as np
import torch
import torch.nn as nn
from torchvision.models import vgg11
import torchvision.transforms as T
import kornia
from multiview_detector.models.resnet import resnet18
from multiview_detector.utils.image_utils import img_color_denormalize, array2heatmap
from multiview_detector.utils.projection import get_worldcoord_from_imgcoord_mat, project_2d_points
from multiview_detector.models.conv_world_feat import ConvWorldFeat, DeformConvWorldFeat
from multiview_detector.models.trans_world_feat import TransformerWorldFeat, DeformTransWorldFeat, \
    DeformTransWorldFeat_aio
import matplotlib.pyplot as plt
from einops import rearrange


def fill_fc_weights(layers):
    for m in layers.modules():
        if isinstance(m, nn.Conv2d):
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)


def output_head(in_dim, feat_dim, out_dim):
    if feat_dim:
        fc = nn.Sequential(nn.Conv2d(in_dim, feat_dim, 3, padding=1), nn.ReLU(),
                           nn.Conv2d(feat_dim, out_dim, 1))
    else:
        fc = nn.Sequential(nn.Conv2d(in_dim, out_dim, 1))
    return fc

def output_head2(in_dim, feat_dim=64, out_dim=1):
    fc = nn.Sequential(nn.Conv2d(in_dim, feat_dim, 3, padding=1), nn.ReLU(),
                       nn.Conv2d(feat_dim, feat_dim * 2, 3, padding=1), nn.ReLU(),
                       nn.Conv2d(feat_dim * 2, out_dim, 1))

    return fc


def create_reference_map(dataset, n_points=4, downsample=2, visualize=False):
    H, W = dataset.Rworld_shape  # H,W; N_row,N_col
    H, W = H // downsample, W // downsample
    ref_y, ref_x = torch.meshgrid(torch.linspace(0.5, H - 0.5, H, dtype=torch.float32),
                                  torch.linspace(0.5, W - 0.5, W, dtype=torch.float32))
    ref = torch.stack((ref_x, ref_y), -1).reshape([-1, 2])
    if n_points == 4:
        zs = [0, 0, 0, 0]
    elif n_points == 8:
        zs = [-0.4, -0.2, 0, 0, 0.2, 0.4, 1, 1.8]
    else:
        raise Exception
    ref_maps = torch.zeros([H * W, dataset.num_cam, n_points, 2])
    world_zoom_mat = np.diag([dataset.world_reduce * downsample, dataset.world_reduce * downsample, 1])
    Rworldgrid_from_worldcoord_mat = np.linalg.inv(
        dataset.base.worldcoord_from_worldgrid_mat @ world_zoom_mat @ dataset.base.world_indexing_from_xy_mat)
    for cam in range(dataset.num_cam):
        mat_0 = Rworldgrid_from_worldcoord_mat @ get_worldcoord_from_imgcoord_mat(dataset.base.intrinsic_matrices[cam],
                                                                                  dataset.base.extrinsic_matrices[cam])
        for i, z in enumerate(zs):
            mat_z = Rworldgrid_from_worldcoord_mat @ get_worldcoord_from_imgcoord_mat(
                dataset.base.intrinsic_matrices[cam],
                dataset.base.extrinsic_matrices[cam],
                z / dataset.base.worldcoord_unit)
            img_pts = project_2d_points(np.linalg.inv(mat_z), ref)
            ref_maps[:, cam, i, :] = torch.from_numpy(project_2d_points(mat_0, img_pts))
        pass
        if visualize:
            fig, ax = plt.subplots()
            field_x = (ref_maps[:, cam, 3, 0] - ref_maps[:, cam, 1, 0]).reshape([H, W])
            field_y = (ref_maps[:, cam, 3, 1] - ref_maps[:, cam, 1, 1]).reshape([H, W])
            ax.streamplot(ref_x.numpy(), ref_y.numpy(), field_x.numpy(), field_y.numpy())
            ax.set_aspect('equal', 'box')
            ax.invert_yaxis()
            plt.show()

    ref_maps[:, :, :, 0] /= W
    ref_maps[:, :, :, 1] /= H
    return ref_maps


class MyRelu(nn.Module):
    def __init__(self, slope: float = -1e-3):
        super(MyRelu, self).__init__()
        self.slope = slope

    def forward(self, feature):
        return torch.where(feature < 0, 0.001, feature)


class MVDeTr(nn.Module):
    def __init__(self, dataset, arch='resnet18', z=0, world_feat_arch='conv',
                 bottleneck_dim=128, outfeat_dim=64, droupout=0.5):
        super().__init__()
        self.myrelu = MyRelu()
        self.Rimg_shape, self.Rworld_shape = dataset.Rimg_shape, dataset.Rworld_shape
        self.img_reduce = dataset.img_reduce

        # world grid change to xy indexing
        world_zoom_mat = np.diag([dataset.world_reduce, dataset.world_reduce, 1])
        Rworldgrid_from_worldcoord_mat = np.linalg.inv(
            dataset.base.worldcoord_from_worldgrid_mat @ world_zoom_mat @ dataset.base.world_indexing_from_xy_mat)

        # z in meters by default
        # projection matrices: img feat -> world feat
        worldcoord_from_imgcoord_mats0 = [get_worldcoord_from_imgcoord_mat(dataset.base.intrinsic_matrices[cam],
                                                                          dataset.base.extrinsic_matrices[cam],
                                                                          0 / dataset.base.worldcoord_unit)
                                         for cam in range(dataset.num_cam)]

        worldcoord_from_imgcoord_mats1 = [get_worldcoord_from_imgcoord_mat(dataset.base.intrinsic_matrices[cam],
                                                                          dataset.base.extrinsic_matrices[cam],
                                                                          0.1 / dataset.base.worldcoord_unit)
                                         for cam in range(dataset.num_cam)]

        worldcoord_from_imgcoord_mats2 = [get_worldcoord_from_imgcoord_mat(dataset.base.intrinsic_matrices[cam],
                                                                          dataset.base.extrinsic_matrices[cam],
                                                                          0.2 / dataset.base.worldcoord_unit)
                                         for cam in range(dataset.num_cam)]

        worldcoord_from_imgcoord_mats3 = [get_worldcoord_from_imgcoord_mat(dataset.base.intrinsic_matrices[cam],
                                                                          dataset.base.extrinsic_matrices[cam],
                                                                          0.3 / dataset.base.worldcoord_unit)
                                         for cam in range(dataset.num_cam)]


        # Rworldgrid(xy)_from_imgcoord(xy)
        self.proj_mats0 = torch.stack([torch.from_numpy(Rworldgrid_from_worldcoord_mat @
                                                       worldcoord_from_imgcoord_mats0[cam])
                                      for cam in range(dataset.num_cam)])

        self.proj_mats1 = torch.stack([torch.from_numpy(Rworldgrid_from_worldcoord_mat @
                                                       worldcoord_from_imgcoord_mats1[cam])
                                      for cam in range(dataset.num_cam)])

        self.proj_mats2 = torch.stack([torch.from_numpy(Rworldgrid_from_worldcoord_mat @
                                                       worldcoord_from_imgcoord_mats2[cam])
                                      for cam in range(dataset.num_cam)])

        self.proj_mats3 = torch.stack([torch.from_numpy(Rworldgrid_from_worldcoord_mat @
                                                       worldcoord_from_imgcoord_mats3[cam])
                                      for cam in range(dataset.num_cam)])



        if arch == 'vgg11':
            self.base = vgg11(pretrained=False).features
            self.base[-1] = nn.Identity()
            self.base[-4] = nn.Identity()
            base_dim = 512
        elif arch == 'resnet18':
            self.base = nn.Sequential(*list(resnet18(pretrained=False,
                                                     replace_stride_with_dilation=[False, True, True]).children())[:-2])
            base_dim = 512
        else:
            raise Exception('architecture currently support [vgg11, resnet18]')

        if bottleneck_dim:
            self.bottleneck = nn.Sequential(nn.Conv2d(base_dim, bottleneck_dim, 1), nn.Dropout2d(droupout))
            base_dim = bottleneck_dim
        else:
            self.bottleneck = nn.Identity()

        # img heads
        self.img_heatmap = output_head(base_dim, outfeat_dim, 1)
        self.img_offset = output_head(base_dim, outfeat_dim, 2)
        self.img_wh = output_head(base_dim, outfeat_dim, 2)
        # self.img_id = output_head(base_dim, outfeat_dim, len(dataset.pid_dict))

        # world feat
        if world_feat_arch == 'conv':
            self.world_feat1 = ConvWorldFeat(dataset.num_cam, dataset.Rworld_shape, base_dim)
        elif world_feat_arch == 'trans':
            self.world_feat1 = TransformerWorldFeat(dataset.num_cam, dataset.Rworld_shape, base_dim)
        elif world_feat_arch == 'deform_conv':
            self.world_feat1 = DeformConvWorldFeat(dataset.num_cam, dataset.Rworld_shape, base_dim)
        elif world_feat_arch == 'deform_trans':
            n_points = 8
            reference_points = create_reference_map(dataset, n_points).repeat([dataset.num_cam, 1, 1, 1])
            self.world_feat1 = DeformTransWorldFeat(dataset.num_cam, dataset.Rworld_shape, 128,
                                                    n_points=n_points, stride=2, reference_points=reference_points)
        elif world_feat_arch == 'aio':
            self.world_feat1 = DeformTransWorldFeat_aio(dataset.num_cam, dataset.Rworld_shape, base_dim)
        else:
            raise Exception

        self.relu = nn.ReLU()
        self.softplus = nn.Softplus()

        self.depth_scales = 4
        self.depth_classifier1 = nn.Sequential(nn.Conv2d(128, 64, 1), nn.ReLU(),
                                              nn.Conv2d(64, self.depth_scales, 1, bias=False)).cuda()

        self.feat_before_merge1 = nn.ModuleDict({
            f'{i}': nn.Conv2d(128, 128, 3, padding=1)
            for i in range(self.depth_scales)
        }).cuda()


        # world heads
        self.world_heatmap1 = output_head(base_dim, outfeat_dim, 1)
        self.world_offset1 = output_head(base_dim, outfeat_dim, 2)
        self.temporal_offset = output_head(base_dim, outfeat_dim, 2)

        # init
        self.img_heatmap[-1].bias.data.fill_(-2.19)
        fill_fc_weights(self.img_offset)
        fill_fc_weights(self.img_wh)
        self.world_heatmap1[-1].bias.data.fill_(-2.19)
        fill_fc_weights(self.world_offset1)
        self.dim_red = nn.Sequential(nn.Conv2d(256, 128, 3, 1, padding=1), nn.ReLU(), )

        pass





    def forward(self, imgs0, M0, imgs1, M1, visualize=True):
        B, N, C, H, W = imgs0.shape
        imgs0 = imgs0.view(B * N, C, H, W)
        imgs1 = imgs1.view(B * N, C, H, W)

        inverse_affine_mats0 = torch.inverse(M0.view([B * N, 3, 3]))
        inverse_affine_mats1 = torch.inverse(M1.view([B * N, 3, 3]))
        # image and world feature maps from xy indexing, change them into world indexing / xy indexing (img)
        imgcoord_from_Rimggrid_mat0 = inverse_affine_mats0 @ \
                                      torch.from_numpy(np.diag([self.img_reduce, self.img_reduce, 1])
                                                       ).view(1, 3, 3).repeat(B * N, 1, 1).float().to(
                                          inverse_affine_mats0.device)

        imgcoord_from_Rimggrid_mat1 = inverse_affine_mats1 @ \
                                      torch.from_numpy(np.diag([self.img_reduce, self.img_reduce, 1])
                                                       ).view(1, 3, 3).repeat(B * N, 1, 1).float().to(
                                          inverse_affine_mats1.device)
        # Rworldgrid(xy)_from_Rimggrid(xy)
        proj_mats0_0 = self.proj_mats0.repeat(B, 1, 1, 1).view(B * N, 3, 3).float().to(inverse_affine_mats0.device) @ imgcoord_from_Rimggrid_mat0
        proj_mats0_1 = self.proj_mats1.repeat(B, 1, 1, 1).view(B * N, 3, 3).float().to(inverse_affine_mats0.device) @ imgcoord_from_Rimggrid_mat0
        proj_mats0_2 = self.proj_mats2.repeat(B, 1, 1, 1).view(B * N, 3, 3).float().to(inverse_affine_mats0.device) @ imgcoord_from_Rimggrid_mat0
        proj_mats0_3 = self.proj_mats3.repeat(B, 1, 1, 1).view(B * N, 3, 3).float().to(inverse_affine_mats0.device) @ imgcoord_from_Rimggrid_mat0
        proj_mats0 = torch.stack((proj_mats0_0, proj_mats0_1, proj_mats0_2, proj_mats0_3), dim=0)


        proj_mats1_0 = self.proj_mats0.repeat(B, 1, 1, 1).view(B * N, 3, 3).float().to(inverse_affine_mats1.device) @ imgcoord_from_Rimggrid_mat1
        proj_mats1_1 = self.proj_mats1.repeat(B, 1, 1, 1).view(B * N, 3, 3).float().to(inverse_affine_mats1.device) @ imgcoord_from_Rimggrid_mat1
        proj_mats1_2 = self.proj_mats2.repeat(B, 1, 1, 1).view(B * N, 3, 3).float().to(inverse_affine_mats1.device) @ imgcoord_from_Rimggrid_mat1
        proj_mats1_3 = self.proj_mats3.repeat(B, 1, 1, 1).view(B * N, 3, 3).float().to(inverse_affine_mats1.device) @ imgcoord_from_Rimggrid_mat1
        proj_mats1 = torch.stack((proj_mats1_0, proj_mats1_1, proj_mats1_2, proj_mats1_3), dim=0)



        imgs_feat = self.base(torch.concat([imgs0, imgs1], dim=0))
        imgs_feat = self.bottleneck(imgs_feat)

        # img heads
        _, C, H, W = imgs_feat.shape
        imgs_heatmap0 = self.img_heatmap(imgs_feat[0:7])
        imgs_offset0 = self.img_offset(imgs_feat[0:7])
        imgs_wh0 = self.img_wh(imgs_feat[0:7])


        imgs_heatmap1 = self.img_heatmap(imgs_feat[7:])
        imgs_offset1 = self.img_offset(imgs_feat[7:])
        imgs_wh1 = self.img_wh(imgs_feat[7:])



        # world feat
        H, W = self.Rworld_shape


        warped_feat0 = 0
        depth_select0 = self.depth_classifier1(imgs_feat[0:7]).softmax(dim=1)

        for i in range(self.depth_scales):
            in_feat0 = imgs_feat[0:7] * depth_select0[:, i][:, None]
            out_feat0 = kornia.geometry.warp_perspective(in_feat0, proj_mats0[i].to(imgs_feat.device),
                                                        self.Rworld_shape, align_corners=False)
            warped_feat0 += self.feat_before_merge1[f'{i}'](out_feat0)  # [b*n,c,h,w]

        warped_feat0 = warped_feat0.view(B, N, C, H, W)




        warped_feat1 = 0
        depth_select1 = self.depth_classifier1(imgs_feat[7:]).softmax(dim=1)

        for i in range(self.depth_scales):
            in_feat1 = imgs_feat[7:] * depth_select1[:, i][:, None]
            out_feat1 = kornia.geometry.warp_perspective(in_feat1, proj_mats1[i].to(imgs_feat.device),
                                                        self.Rworld_shape, align_corners=False)
            warped_feat1 += self.feat_before_merge1[f'{i}'](out_feat1)  # [b*n,c,h,w]

        warped_feat1 = warped_feat1.view(B, N, C, H, W)

        world_feat_prev = self.world_feat1(warped_feat0, visualize=visualize)

        temporal_bev = rearrange(
            torch.stack([world_feat_prev[None], warped_feat1], 2),
            'b v t c h w -> b v (t c) h w')

        world_feat = self.world_feat1(self.dim_red(temporal_bev[0])[None], prev=False, visualize=visualize)

        # world heads
        world_heatmap = self.world_heatmap1(world_feat)
        world_heatmap = torch.where(world_heatmap < 0, -world_heatmap, world_heatmap)
        world_offset = self.world_offset1(world_feat)
        temporal_offset = self.temporal_offset(world_feat)

        wld_bev = {
            'world_heatmap': world_heatmap,
            'world_offset': world_offset,
            'temporal_offset': temporal_offset
        }

        img_prediction0 = {
            'imgs_heatmap': imgs_heatmap0,
            'imgs_offset': imgs_offset0,
            'imgs_wh': imgs_wh0,
        }

        img_prediction1 = {
            'imgs_heatmap': imgs_heatmap1,
            'imgs_offset': imgs_offset1,
            'imgs_wh': imgs_wh1,
        }

        x = world_heatmap[0, 0]
        coord1 = torch.nonzero(torch.ones(120, 360)).to(x.device)
        denval1 = x[coord1[:, 0], coord1[:, 1]]
        offset = temporal_offset[0, :, coord1[:, 0], coord1[:, 1]]
        coord1 = coord1.float()
        coord1[:, [0, 1]] = coord1[:, [1, 0]]
        transformed_coords = (offset.transpose(0, 1) + coord1) / float(360)

        return wld_bev, img_prediction0, img_prediction1, denval1[None, ..., None], transformed_coords[None, ...]


