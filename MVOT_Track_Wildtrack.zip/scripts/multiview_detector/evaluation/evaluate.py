

def evaluate(res_fpath, gt_fpath, dataset='wildtrack'):

    from multiview_detector.evaluation.pyeval.evaluateDetection import evaluateDetection_py

    recall, precision, moda, modp = evaluateDetection_py(res_fpath, gt_fpath, dataset)
    return recall, precision, moda, modp


if __name__ == "__main__":
    import os

    res_fpath = os.path.abspath('test-demo.txt')
    gt_fpath = os.path.abspath('gt-demo.txt')
    os.chdir('../..')
    print(os.path.abspath('.'))


    recall, precision, moda, modp = evaluate(res_fpath, gt_fpath, 'Wildtrack')
    print(f'eval: MODA {moda:.1f}, MODP {modp:.1f}, prec {precision:.1f}, rcll {recall:.1f}')
