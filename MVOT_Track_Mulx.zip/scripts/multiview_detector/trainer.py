import time
import os
import numpy as np
import torch
from torch import nn
from torch.cuda.amp import autocast
import matplotlib.pyplot as plt
from PIL import Image
from multiview_detector.loss import *
from multiview_detector.evaluation.evaluate import evaluate
from multiview_detector.utils.decode import ctdet_decode, mvdet_decode
from multiview_detector.utils.nms import nms
from multiview_detector.utils.image_utils import add_heatmap_to_image, img_color_denormalize
from multiview_detector.loss.ot_loss.genloss import GeneralizedLoss, GeneralizedLoss2, GeneralizedLoss3
from tracking.multitracker import JDETracker
from multiview_detector.evaluation.mot_bev import mot_metrics_pedestrian

def move_tensors_to_device(d, device='cuda:0'):
    for key, value in d.items():
        if isinstance(value, torch.Tensor):
            d[key] = value.to(device)
        elif isinstance(value, dict):
            move_tensors_to_device(value, device)

class BaseTrainer(object):
    def __init__(self):
        super(BaseTrainer, self).__init__()


class PerspectiveTrainer(BaseTrainer):
    def __init__(self, model, logdir, cls_thres=0.4, alpha=1.0, use_mse=False, id_ratio=0):
        super(BaseTrainer, self).__init__()
        self.model = model
        self.mse_loss = nn.MSELoss(reduction='mean')
        self.focal_loss = FocalLoss()
        self.regress_loss = RegL1Loss()
        self.ce_loss = RegCELoss()

        self.ot_loss_ed = GeneralizedLoss(type='ed')
        self.ot_loss_md = GeneralizedLoss(type='md')
        self.offset_ot = GeneralizedLoss2()
        self.ot_temporal = GeneralizedLoss3()
        self.PI_ot = GeneralizedLoss2()


        self.cls_thres = cls_thres
        self.logdir = logdir
        self.denormalize = img_color_denormalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
        self.alpha = alpha
        self.use_mse = use_mse
        self.id_ratio = id_ratio

    def bev_loss(self, bev_prediction, **kwargs):

        world_heatmap = bev_prediction['world_heatmap']
        world_offset = bev_prediction['world_offset']
        temporal_offset = bev_prediction['temporal_offset']

        offset_loss_l1 = torch.nn.functional.smooth_l1_loss(temporal_offset,  kwargs['tem_offset'][0], reduction='sum')

        loss_w = self.ot_loss_md(world_heatmap, kwargs['points']) \
                 + self.regress_loss(world_offset, kwargs['reg_mask'], kwargs['idx'], kwargs['qua_offset']) \
                 + offset_loss_l1

        return loss_w

    def img_loss(self, img_prediction, **kwargs):

        imgs_heatmap = img_prediction['imgs_heatmap']
        imgs_wh = img_prediction['imgs_offset']
        imgs_offset = img_prediction['imgs_wh']


        loss_img_hm = self.focal_loss(imgs_heatmap, kwargs['heatmap'])
        loss_img_wh = self.regress_loss(imgs_wh, kwargs['reg_mask'], kwargs['idx'], kwargs['wh'])
        loss_img_off = self.regress_loss(imgs_offset, kwargs['reg_mask'], kwargs['idx'], kwargs['offset'])
        loss_img = loss_img_hm + loss_img_off + loss_img_wh * 0.1
        return loss_img / 6.0



    def train(self, epoch, dataloader, optimizer, scaler, scheduler=None, log_interval=100):
        self.model.train()

        losses = 0
        t0 = time.time()
        t_b = time.time()
        t_forward = 0
        t_backward = 0
        for batch_idx, all_frames in enumerate(dataloader):
            B, N = all_frames['frame0']['imgs_gt']['heatmap'].shape[:2]
            move_tensors_to_device(all_frames)

            for key in all_frames['frame0']['imgs_gt'].keys():
                all_frames['frame0']['imgs_gt'][key] = all_frames['frame0']['imgs_gt'][key].view([B * N] + list(all_frames['frame0']['imgs_gt'][key].shape)[2:])
            for key in all_frames['frame1']['imgs_gt'].keys():
                all_frames['frame1']['imgs_gt'][key] = all_frames['frame1']['imgs_gt'][key].view([B * N] + list(all_frames['frame1']['imgs_gt'][key].shape)[2:])


            data0 = all_frames['frame0']['img']
            data1 = all_frames['frame1']['img']
            affine_mats0 = all_frames['frame0']['affine_mats']
            affine_mats1 = all_frames['frame1']['affine_mats']

            bev_prediction, img0_prediction, img1_prediction, trans_val, trans_coord = self.model(data0, affine_mats0, data1, affine_mats1)


            bev_loss = self.bev_loss(bev_prediction,
                                     points=all_frames['frame1']['wld_point'],
                                     reg_mask=all_frames['frame1']['wld_gt']['reg_mask'],
                                     idx=all_frames['frame1']['wld_gt']['idx'],
                                     qua_offset=all_frames['frame1']['wld_gt']['offset'],
                                     tem_offset=all_frames['temporal_offset'])


            img_loss0 = self.img_loss(img0_prediction,
                                     heatmap=all_frames['frame0']['imgs_gt']['heatmap'],
                                     reg_mask=all_frames['frame0']['imgs_gt']['reg_mask'],
                                     idx=all_frames['frame0']['imgs_gt']['idx'],
                                     wh=all_frames['frame0']['imgs_gt']['wh'],
                                     offset=all_frames['frame0']['imgs_gt']['offset'])


            img_loss1 = self.img_loss(img1_prediction,
                                     heatmap=all_frames['frame1']['imgs_gt']['heatmap'],
                                     reg_mask=all_frames['frame1']['imgs_gt']['reg_mask'],
                                     idx=all_frames['frame1']['imgs_gt']['idx'],
                                     wh=all_frames['frame1']['imgs_gt']['wh'],
                                     offset=all_frames['frame1']['imgs_gt']['offset'])

            matching_loss = self.ot_temporal(trans_coord, trans_val, all_frames['frame0']['wld_point'], all_frames['GT_Plan'][None])
            loss = (img_loss0 + img_loss1) + bev_loss + 0.01*matching_loss



            t_f = time.time()
            t_forward += t_f - t_b

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            losses += loss.item()

            t_b = time.time()
            t_backward += t_b - t_f

            if scheduler is not None:
                if isinstance(scheduler, torch.optim.lr_scheduler.OneCycleLR):
                    scheduler.step()
                elif isinstance(scheduler, torch.optim.lr_scheduler.CosineAnnealingWarmRestarts) or \
                        isinstance(scheduler, torch.optim.lr_scheduler.LambdaLR):
                    scheduler.step(epoch - 1 + batch_idx / len(dataloader))

            if (batch_idx + 1) % log_interval == 0 or batch_idx + 1 == len(dataloader):
                t1 = time.time()
                t_epoch = t1 - t0

                print(f'wloss={bev_loss}, imgloss={img_loss0 + img_loss1}')
                t = bev_prediction['world_heatmap']
                print(f'Train Epoch: {epoch}, Batch:{(batch_idx + 1)}, loss: {losses / (batch_idx + 1):.6f}, '
                      f'Time: {t_epoch:.1f}, maxima: {t.max():.3f}, p_loss={matching_loss}')


        return losses / len(dataloader)

    def test(self, epoch, dataloader, res_fpath=None, visualize=False):
        test_tracker = JDETracker(conf_thres=0.4)
        self.model.eval()
        losses = 0
        res_list = []
        mota_gt_list, mota_pred_list = [], []
        t0 = time.time()
        for batch_idx, all_frames in enumerate(dataloader):
            frame = all_frames['frame1']['frame_id']
            B, N = all_frames['frame0']['imgs_gt']['heatmap'].shape[:2]
            move_tensors_to_device(all_frames)

            for key in all_frames['frame0']['imgs_gt'].keys():
                all_frames['frame0']['imgs_gt'][key] = all_frames['frame0']['imgs_gt'][key].view([B * N] + list(all_frames['frame0']['imgs_gt'][key].shape)[2:])
            for key in all_frames['frame1']['imgs_gt'].keys():
                all_frames['frame1']['imgs_gt'][key] = all_frames['frame1']['imgs_gt'][key].view([B * N] + list(all_frames['frame1']['imgs_gt'][key].shape)[2:])


            data0 = all_frames['frame0']['img']
            data1 = all_frames['frame1']['img']
            affine_mats0 = all_frames['frame0']['affine_mats']
            affine_mats1 = all_frames['frame1']['affine_mats']

            with torch.no_grad():
                bev_prediction, img0_prediction, img1_prediction,_, _ = self.model(data0, affine_mats0, data1, affine_mats1)

            world_heatmap = bev_prediction['world_heatmap']
            world_heatmap = (world_heatmap - torch.min(world_heatmap)) / (
                    torch.max(world_heatmap) - torch.min(world_heatmap))


            if res_fpath is not None:
                xys, prev_xy = mvdet_decode(torch.sigmoid(world_heatmap.detach().cpu()),
                                   bev_prediction['world_offset'].detach().cpu(),
                                   bev_prediction['temporal_offset'].detach().cpu(),
                                   reduce=dataloader.dataset.world_reduce)

                grid_xy, scores = xys[:, :, :2], xys[:, :, 2:3]
                if dataloader.dataset.base.indexing == 'xy':
                    positions = grid_xy
                    positions_prev = prev_xy
                else:
                    positions = grid_xy[:, :, [1, 0]]
                    positions_prev = prev_xy[:, :, [1, 0]]


                for b in range(B):
                    ids = scores[b].squeeze() > self.cls_thres
                    pos, s = positions[b, ids], scores[b, ids, 0]
                    pos_prev = positions_prev[b, ids]
                    res = torch.cat([torch.ones([len(s), 1]) * frame[b], pos], dim=1)
                    ids, count = nms(pos, s, 20, np.inf)
                    res = torch.cat([torch.ones([count, 1]) * frame[b], pos[ids[:count]]], dim=1)
                    res_list.append(res)


                    grid_gt = all_frames['frame1']['org_grid_gt_w_id'][0]
                    output_stracks = test_tracker.update(pos[ids[:count]], pos_prev[ids[:count]], s[ids[:count]])

                    mota_gt_list.extend([[frame.item(), i.item(), -1, -1, -1, -1, 1, x.item(), y.item(), -1]
                                         for x, y, i in grid_gt[grid_gt.sum(1) != 0]])
                    mota_pred_list.extend(
                        [[frame.item(), s.track_id, -1, -1, -1, -1, s.score.item()] + s.xy.tolist() + [-1]
                         for s in output_stracks])




        t1 = time.time()
        t_epoch = t1 - t0

        if visualize:
            fig = plt.figure()
            subplt0 = fig.add_subplot(211, title="output")
            subplt1 = fig.add_subplot(212, title="target")

            key_point = all_frames['frame1']['wld_point'].squeeze().detach().cpu().numpy()

            gt_map = np.zeros([160, 250])

            key_point[:, 0] = (key_point[:, 0] * 1000) / 4
            key_point[:, 1] = (key_point[:, 1] * 1000) / 4

            key_point[:, [0, 1]] = key_point[:, [1, 0]]

            key_point = key_point.astype(int)

            gt_map[key_point[:, 0], key_point[:, 1]] = 1
            subplt0.imshow(world_heatmap.cpu().detach().numpy().squeeze())
            subplt1.imshow(gt_map)
            plt.savefig(os.path.join(self.logdir, f'world{epoch if epoch else ""}.jpg'), dpi=500.0)
            plt.close(fig)

            # visualizing the heatmap for per-view estimation
            heatmap0_foot = img1_prediction['imgs_heatmap'][0].detach().cpu().numpy().squeeze()
            img0 = self.denormalize(all_frames['frame1']['img'][0, 0]).cpu().numpy().squeeze().transpose([1, 2, 0])
            img0 = Image.fromarray((img0 * 255).astype('uint8'))
            foot_cam_result = add_heatmap_to_image(heatmap0_foot, img0)
            foot_cam_result.save(os.path.join(self.logdir, f'cam1_foot.jpg'))

        if res_fpath is not None:
            print(dataloader.dataset.gt_fpath)
            res_list = torch.cat(res_list, dim=0).numpy() if res_list else np.empty([0, 3])

            np.savetxt(res_fpath, res_list, '%d')
            recall, precision, moda, modp = evaluate(os.path.abspath(res_fpath),
                                                     os.path.abspath(dataloader.dataset.gt_fpath),
                                                     dataloader.dataset.base.__name__)

            pred_path = os.path.join('', 'mota_pred.txt')
            gt_path = os.path.join('', 'mota_gt.txt')
            np.savetxt(pred_path, np.array(mota_pred_list), '%f', delimiter=',')
            np.savetxt(gt_path, np.array(mota_gt_list), '%f', delimiter=',')
            summary = mot_metrics_pedestrian(os.path.abspath(pred_path), os.path.abspath(gt_path))
            for key, value in summary.iloc[0].to_dict().items():
                print(f'track/{key}', value)


            print(f'moda: {moda:.1f}%, modp: {modp:.1f}%, prec: {precision:.1f}%, recall: {recall:.1f}%')
        else:
            moda = 0
            modp = 0

        print(f'Test, loss: {losses / len(dataloader):.6f}, Time: {t_epoch:.3f}')
        return losses / len(dataloader), moda, modp
